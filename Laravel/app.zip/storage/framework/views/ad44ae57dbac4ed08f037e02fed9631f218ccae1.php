<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Dashboard</div>

                <div class="panel-body">
                    <p>Dados do Usuário:</p> 
                    <p>Nome:<?php echo e($user->name); ?></p> 
                    <p>Email:<?php echo e($user->email); ?></p> 
                    <p>Github:<?php echo e($user->github); ?></p> 
                    <p>Facebook:<?php echo e($user->facebook); ?></p> 
                    <br>
                    <?php if($user->github): ?>
                        <a class="btn btn-default disabled"> Conectado com o GitbHub</a>
                    <?php else: ?>
                        <a href="<?php echo e(url('/entrar/github')); ?>" class="btn btn btn-primary"> Conectar com o GitbHub</a>
                    <?php endif; ?>
                    <?php if($user->facebook): ?>
                        <a class="btn btn btn-primary"> Conectado com o Facebook</a>
                        <?php else: ?>
                        <a href="<?php echo e(url('/entrar/facebook')); ?>" class="btn btn btn-primary"> Conectar com o Facebook</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>